<section class="noticias-section">
    <div class="noticias-content">
        <h2>Últimas Notícias</h2>

        <div class="noticia-item">
            <div class="noticia-card">
                <h3>Novo projeto de leitura</h3>
                <p class="data">10 de Novembro de 2024</p>
                <p class="descricao">Estamos lançando um novo projeto de incentivo à leitura para crianças e jovens.</p>
            </div>
        </div>

        <div class="noticia-item">
            <div class="noticia-card">
                <h3>Evento comunitário</h3>
                <p class="data">5 de Novembro de 2024</p>
                <p class="descricao">Convidamos todos para participar do evento comunitário na biblioteca.</p>
            </div>
        </div>
        <div class="noticia-item">
            <div class="noticia-card">
                <h3>Evento comunitário</h3>
                <p class="data">5 de Novembro de 2024</p>
                <p class="descricao">Convidamos todos para participar do evento comunitário na biblioteca.</p>
            </div>
        </div>

        <div class="noticia-item">
            <div class="noticia-card">
                <h3>Evento comunitário</h3>
                <p class="data">5 de Novembro de 2024</p>
                <p class="descricao">Convidamos todos para participar do evento comunitário na biblioteca.</p>
            </div>
        </div>
        <div class="noticia-item">
            <div class="noticia-card">
                <h3>Evento comunitário</h3>
                <p class="data">5 de Novembro de 2024</p>
                <p class="descricao">Convidamos todos para participar do evento comunitário na biblioteca.</p>
            </div>
        </div>

    </div>
</section>