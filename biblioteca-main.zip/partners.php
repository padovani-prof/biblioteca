<section class="partners">
    <h2>Nossos Parceiros</h2>
    <div class="partners-container">
        <div class="partner">
            <img src="assets/preview.png" alt="Parceiro 1" />
        </div>
        <div class="partner">
            <img src="assets/proex_400.png" alt="Parceiro 2" />
        </div>
        <div class="partner">
            <img src="assets/uea_logo_horizontal_verde.png" alt="Parceiro 3" />
        </div>
        <div class="partner">
            <img src="assets/E-mail-PROEX-3-removebg-preview.png" alt="Parceiro 4" />
        </div>
    </div>
</section>