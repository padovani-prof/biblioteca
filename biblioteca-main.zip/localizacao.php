<section class="location-section">
    <div class="location-details">
        <h2>Endereço</h2>
        <p>R. Padre Calebe, 3725 - Mamoud Amed, Itacoatiara, Amazonas - Brasil<br>CEP: 69100-000</p>

        <h2>Telefone</h2>
        <p>(92) 98488-2959</p>

        <h2>E-mail</h2>
        <p>biblioteca.com.br</p>
    </div>
    <div class="location-map">
        <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3926.092145456977!2d-58.460013684853755!3d-3.1372920977252846!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9261d4325d77b7d7%3A0x836c35a015b24b95!2sR.%20Padre%20Calebe%2C%203725%20-%20Mamoud%20Amed%2C%20Itacoatiara%20-%20AM%2C%2069100-000!5e0!3m2!1sen!2sbr!4v1698787733623!5m2!1sen!2sbr"
            width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"
            referrerpolicy="no-referrer-when-downgrade">
        </iframe>
    </div>
</section>