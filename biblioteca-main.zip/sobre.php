<section class="sobre">
    <h3>SOBRE A BIBLIOTECA</h3>
    <h2>SOBRE NÓS!</h2>
    <p>Biblioteca Comunitária, um ponto de cultura e humanização</p>
    <p>Um espaço da produção de diferentes manifestações artísticas. Além de propiciar o acesso a diversidade literária
        para a comunidade, a biblioteca realiza rodas de leituras, rodas musicais, concurso de poesia e desenho e
        oficinas de contação de histórias.</p>
    <a href="how_it_started.php" class="btn-sobre"><button class="btn-sobre">Saiba Mais</button></a>
</section>